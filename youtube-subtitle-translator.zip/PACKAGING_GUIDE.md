# 如何打包與發布 Chrome Extension

## 1. 打包擴充功能（發布用）

如果你是指將目前的開發成果打包成可以安裝或上架的檔案（`.zip`）：

### 方法 A：使用 Chrome 瀏覽器打包（生成 .crx）
1. 開啟 `chrome://extensions/`
2. 點擊上方的 **"Pack extension" (打包擴充功能)** 按鈕。
3. **Extension root directory**: 選擇你的專案資料夾 `/Users/jameswei/Downloads/youtube-subtitle-translator-main`。
4. **Private key file**: 第一次打包時留空（Chrome 會生成一個 `.pem` 密鑰給你，請妥善保存，更新版本時需要）。
5. 點擊 **"Pack extension"**。
   - 生成 `.crx`：可直接拖入瀏覽器安裝（需開啟開發者模式）。
   - 生成 `.pem`：私鑰。

### 方法 B：手動壓縮（上架 Chrome Web Store 用）
Chrome Web Store 要求上傳 `.zip` 檔案。
1. 在專案根目錄，選中所有必要檔案：
   - `manifest.json`
   - `content.js`
   - `background.js`
   - `popup.html`
   - `popup.js`
   - `styles.css`
   - `icons/` 資料夾
2. **排除** 開發用檔案（如 `.git`, `.DS_Store`, `test_harness.html`, `mock_env.js` 等）。
3. 右鍵 -> 壓縮 (Compress) 生成 `.zip` 檔。

---

## 2. 在擴充功能中使用 NPM Packages（引入第三方庫）

如果你是指「如何在程式碼中使用 npm 下載的套件」（如 `lodash`, `axios`）：

目前專案是 **原生 JavaScript (Vanilla JS)**，無法直接使用 `import _ from 'lodash'`。你需要引入 **Bundler (打包工具)**。

### 步驟 1：初始化 npm
在專案根目錄執行：
```bash
npm init -y
```

### 步驟 2：安裝打包工具 (Vite)
我們推薦使用 Vite，它配置簡單且速度快。
```bash
npm install -D vite @crxjs/vite-plugin
```

### 步驟 3：安裝你想要的套件
例如安裝 `lodash`：
```bash
npm install lodash
```

### 步驟 4：配置 `vite.config.js`
在根目錄建立 `vite.config.js`：
```javascript
import { defineConfig } from 'vite'
import { crx } from '@crxjs/vite-plugin'
import manifest from './manifest.json'

export default defineConfig({
  plugins: [crx({ manifest })],
})
```

### 步驟 5：修改程式碼
現在你可以在 `content.js` 中使用 import 了：
```javascript
import { debounce } from 'lodash';

// 使用 lodash 的 debounce
const handleHover = debounce((event) => {
  // ...
}, 250);
```

### 步驟 6：構建
執行 `npx vite build`，它會讀取你的 `manifest.json`，解析所有依賴，並在 `dist/` 資料夾中生成打包好的擴充功能。載入擴充功能時選擇 `dist/` 資料夾即可。
